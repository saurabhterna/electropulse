#!/bin/bash
# ElectroPulse Patch — Apply Election Variant
# Run this from your electropulse project root folder
# Usage: bash apply-patch.sh

set -e

echo "⚡ Applying ElectroPulse election variant patch..."

# Check we're in the right directory
if [ ! -f "package.json" ] || [ ! -d "src/config" ]; then
  echo "❌ Error: Run this from your electropulse project root (where package.json is)"
  exit 1
fi

PATCH_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "  → Updating index.html (branding + meta tags)"
cp "$PATCH_DIR/index.html" ./index.html

echo "  → Updating src/config/variant.ts (force election variant)"
cp "$PATCH_DIR/variant.ts" ./src/config/variant.ts

echo "  → Updating src/config/variant-meta.ts (ElectroPulse SEO metadata)"
cp "$PATCH_DIR/variant-meta.ts" ./src/config/variant-meta.ts

echo "  → Updating src/config/map-layer-definitions.ts (election layer config)"
cp "$PATCH_DIR/map-layer-definitions.ts" ./src/config/map-layer-definitions.ts

echo "  → Updating src/config/panels.ts (election panels + all worldmonitor layers off)"
cp "$PATCH_DIR/panels.ts" ./src/config/panels.ts

echo "  → Updating src/app/panel-layout.ts (ElectroPulse header/footer branding)"
cp "$PATCH_DIR/panel-layout.ts" ./src/app/panel-layout.ts

echo ""
echo "✅ Patch applied! Now run:"
echo ""
echo "   git add -A"
echo "   git commit -m 'feat: add ElectroPulse election variant — strip worldmonitor layers, rebrand for India 2026'"
echo "   git push origin main"
echo "   vercel --prod"
echo ""
echo "⚡ ElectroPulse is ready to deploy!"
